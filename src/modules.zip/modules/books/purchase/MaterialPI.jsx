import React, { useEffect, useMemo, useState } from 'react';
import { collection, deleteDoc, doc, onSnapshot } from 'firebase/firestore';
import { auth, db } from '../../../firebaseConfig';
import UploadPI from './UploadPI';

const MAROON = '#8B0000';

const MaterialPI = () => {
  const [loading, setLoading] = useState(true);
  const [pis, setPis] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [openUpload, setOpenUpload] = useState(false);
  const [role, setRole] = useState('');

  const isAdmin = role === 'admin';

  useEffect(() => {
    const hydrateUser = async () => {
      let nextRole = '';
      try {
        const session = JSON.parse(localStorage.getItem('kp-user') || '{}');
        nextRole = String(session?.profile?.role || session?.role || '').toLowerCase();
      } catch {}
      if (!nextRole && auth.currentUser?.getIdTokenResult) {
        try {
          const token = await auth.currentUser.getIdTokenResult();
          nextRole = String(token?.claims?.role || '').toLowerCase();
        } catch {}
      }
      setRole(nextRole);
    };
    hydrateUser();
  }, []);

  useEffect(() => {
    const unsubs = [];

    unsubs.push(onSnapshot(collection(db, 'pis'), (snap) => {
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      list.sort((a, b) => Number(b.createdAt?.seconds || 0) - Number(a.createdAt?.seconds || 0));
      setPis(list);
      setLoading(false);
    }));

    unsubs.push(onSnapshot(collection(db, 'records_materialVendors'), (snap) => {
      setVendors(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    }));

    return () => unsubs.forEach((u) => u());
  }, []);

  const rows = useMemo(() => pis.map((pi) => {
    const createdDate = pi.createdAt?.toDate ? pi.createdAt.toDate().toISOString().slice(0, 10) : '-';
    return {
      ...pi,
      createdDate,
    };
  }), [pis]);

  const handleDelete = async (id) => {
    if (!isAdmin) return;
    await deleteDoc(doc(db, 'pis', id));
  };

  if (loading) return <div>Loading PI...</div>;

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
        <button style={primaryBtn} onClick={() => setOpenUpload(true)}>Upload PI</button>
      </div>

      <div style={{ background: '#fff', border: '1px solid #ececec', borderRadius: 8, overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: '#f8f8f8' }}>
              <th style={th}>Created Date</th>
              <th style={th}>PI Number</th>
              <th style={th}>Vendor Name</th>
              <th style={th}>PI Amount</th>
              <th style={th}>Upload / View</th>
              <th style={th}>Delete</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id}>
                <td style={td}>{row.createdDate}</td>
                <td style={td}>{row.piNumber}</td>
                <td style={td}>{row.vendorName}</td>
                <td style={td}>{Number(row.piAmount || 0).toLocaleString('en-IN')}</td>
                <td style={td}>
                  {row.piPdfUrl ? (
                    <a href={row.piPdfUrl} target="_blank" rel="noreferrer">View PI</a>
                  ) : (
                    <span>-</span>
                  )}
                </td>
                <td style={td}>
                  <button style={dangerBtn} disabled={!isAdmin} onClick={() => handleDelete(row.id)}>Delete</button>
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td style={{ ...td, textAlign: 'center' }} colSpan={6}>No PI records yet</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <UploadPI open={openUpload} onClose={() => setOpenUpload(false)} vendors={vendors} />
    </div>
  );
};

const th = { textAlign: 'left', padding: '12px 10px', borderBottom: '1px solid #ececec', whiteSpace: 'nowrap' };
const td = { padding: '12px 10px', borderBottom: '1px solid #f1f1f1', whiteSpace: 'nowrap' };

const primaryBtn = {
  height: 34,
  border: 'none',
  borderRadius: 6,
  padding: '0 12px',
  background: MAROON,
  color: '#fff',
  fontWeight: 600,
  cursor: 'pointer',
};

const dangerBtn = {
  height: 30,
  border: 'none',
  borderRadius: 6,
  padding: '0 10px',
  background: '#b00',
  color: '#fff',
  cursor: 'pointer',
};

export default MaterialPI;
