import React, { useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { collection, deleteDoc, doc, getDoc, onSnapshot, serverTimestamp, updateDoc } from 'firebase/firestore';
import { auth, db } from '../../../firebaseConfig';
import CreateServicePO from './CreateServicePO';
import ServicePOApproval from './ServicePOApproval';
import ServicePOPayment from './ServicePOPayment';
import {
  extractRoleFromSession,
  isFinanceOrAdminRole,
  MAROON,
  normalizeRole,
  createNotificationIfNotExists,
} from './purchaseHelpers';

const formatMoney = (value) => Number(value || 0).toLocaleString('en-IN');

const ServicePO = () => {
  const location = useLocation();
  const [rows, setRows] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [currentUserRole, setCurrentUserRole] = useState('');
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('purchase');
  const [searchPo, setSearchPo] = useState('');
  const [periodDate, setPeriodDate] = useState('');
  const [openCreate, setOpenCreate] = useState(false);
  const [busyId, setBusyId] = useState('');

  useEffect(() => {
    const params = new URLSearchParams(location.search || '');
    const tab = String(params.get('tab') || '').toLowerCase();
    if (tab === 'approval') setActiveTab('approval');
  }, [location.search]);

  useEffect(() => {
    const hydrateUser = async () => {
      let role = '';
      try {
        const session = JSON.parse(localStorage.getItem('kp-user') || '{}');
        role = extractRoleFromSession(session);
      } catch {}
      if (!role && auth.currentUser?.getIdTokenResult) {
        try {
          const token = await auth.currentUser.getIdTokenResult();
          role = normalizeRole(token?.claims?.role || token?.claims?.Role || '');
        } catch {}
      }
      if (!role && auth.currentUser?.uid) {
        try {
          const snap = await getDoc(doc(db, 'Users', auth.currentUser.uid));
          if (snap.exists()) {
            role = normalizeRole(snap.data()?.role || snap.data()?.Role || '');
          }
        } catch (err) {
          console.error('❌ Failed to hydrate role from Users collection', err?.message || err);
        }
      }
      setCurrentUserRole(role);
    };
    hydrateUser();
  }, []);

  useEffect(() => {
    const unsubs = [];
    unsubs.push(onSnapshot(collection(db, 'servicePurchaseOrders'), (snap) => {
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      list.sort((a, b) => Number(b.createdAt?.seconds || 0) - Number(a.createdAt?.seconds || 0));
      setRows(list);
      setLoading(false);
    }));
    unsubs.push(onSnapshot(collection(db, 'records_serviceVendors'), (snap) => {
      setVendors(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    }));
    return () => unsubs.forEach((u) => u());
  }, []);

  const sendForApproval = async (row) => {
    setBusyId(row.id);
    try {
      await updateDoc(doc(db, 'servicePurchaseOrders', row.id), {
        status: 'pending_approval',
        updatedAt: serverTimestamp(),
      });
      await createNotificationIfNotExists({
        dedupeKey: `service_po_approval_${row.id}_pending_approval`,
        title: 'PO Approval Required',
        message: `${row.poNumber} requires approval`,
        type: 'po_approval',
        module: 'books',
        referenceId: row.id,
        referenceType: 'servicePurchaseOrder',
        toRole: 'finance_manager',
      });
    } catch (e) {
      alert(e?.message || 'Failed to send approval');
    } finally {
      setBusyId('');
    }
  };

  const financeVisible = isFinanceOrAdminRole(currentUserRole);
  const isAdmin = normalizeRole(currentUserRole) === 'admin';

  const filteredRows = useMemo(() => {
    const term = String(searchPo || '').trim().toLowerCase();
    return rows.filter((row) => {
      const poMatch = !term || String(row.poNumber || '').toLowerCase().includes(term);
      const createdDate = row.createdDate || (row.createdAt?.seconds ? new Date(row.createdAt.seconds * 1000).toISOString().slice(0, 10) : '');
      const dateMatch = !periodDate || createdDate === periodDate;
      return poMatch && dateMatch;
    });
  }, [rows, searchPo, periodDate]);

  const handleDelete = async (row) => {
    if (!isAdmin || !row?.id) return;
    try {
      await deleteDoc(doc(db, 'servicePurchaseOrders', row.id));
    } catch (e) {
      alert(e?.message || 'Delete failed');
    }
  };

  if (loading) return <div>Loading service PO...</div>;

  return (
    <div>
      <div style={{ display: 'flex', gap: 12, marginBottom: 12 }}>
        <button
          style={activeTab === 'purchase' ? primaryBtn : tabBtn}
          onClick={() => setActiveTab('purchase')}
        >
          Purchase Orders
        </button>
        <button
          style={activeTab === 'approval' ? primaryBtn : tabBtn}
          onClick={() => setActiveTab('approval')}
        >
          Financial approval Queue
        </button>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, marginBottom: 12, flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          <input
            value={searchPo}
            onChange={(e) => setSearchPo(e.target.value)}
            placeholder="Search by PO number"
            style={{ ...inputStyle, minWidth: 170, background: '#cfeaf7' }}
          />
          <input
            type="date"
            value={periodDate}
            onChange={(e) => setPeriodDate(e.target.value)}
            style={{ ...inputStyle, minWidth: 170, background: '#d9eef8' }}
            title="Select period(date)"
          />
        </div>

        <div style={{ display: 'flex', gap: 8 }}>
          <button style={primaryBtn} onClick={() => setOpenCreate(true)}>Create PO</button>
        </div>
      </div>

      {activeTab === 'purchase' ? (
        <div style={{ background: '#fff', border: '1px solid #ececec', borderRadius: 8, overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: '#f8f8f8' }}>
                <th style={th}>Created Date</th>
                <th style={th}>PO Number</th>
                <th style={th}>Vendor</th>
                <th style={th}>Assigned Projects Count</th>
                <th style={th}>PO Value</th>
                <th style={th}>Paid Amount</th>
                <th style={th}>Pending</th>
                <th style={th}>View PO</th>
                <th style={th}>Approval</th>
                <th style={th}>Status</th>
                <th style={th}>Receipt</th>
                {isAdmin && <th style={th}>Delete</th>}
              </tr>
            </thead>
            <tbody>
              {filteredRows.map((row) => {
                const pending = Math.max(0, Number(row.totalAmount || 0) - Number(row.paymentAmount || 0));
                const status = String(row.status || 'draft').toLowerCase();
                const paymentStatus = String(row.paymentStatus || (pending <= 0 ? 'paid' : Number(row.paymentAmount || 0) > 0 ? 'partial' : 'pending')).toLowerCase();
                const createdDate = row.createdDate || (row.createdAt?.seconds ? new Date(row.createdAt.seconds * 1000).toISOString().slice(0, 10) : '-');
                return (
                  <tr key={row.id}>
                    <td style={td}>{createdDate}</td>
                    <td style={td}>{row.poNumber}</td>
                    <td style={td}>{row.vendorName || '-'}</td>
                    <td style={td}>{Number(row.assignedProjectsCount || 0)}</td>
                    <td style={td}>{formatMoney(row.totalAmount)}</td>
                    <td style={td}>{formatMoney(row.paymentAmount)}</td>
                    <td style={td}>{formatMoney(pending)}</td>
                    <td style={td}>{row.poPdfUrl ? <a href={row.poPdfUrl} target="_blank" rel="noreferrer">PDF</a> : '-'}</td>
                    <td style={td}>
                      {status === 'draft' ? (
                        <button style={primaryBtn} disabled={busyId === row.id} onClick={() => sendForApproval(row)}>
                          {busyId === row.id ? 'Sending...' : 'Send for Approval'}
                        </button>
                      ) : (
                        <span style={{ color: status === 'approved' ? '#1f7a1f' : '#9c6f00', fontWeight: 700 }}>{status.replaceAll('_', ' ')}</span>
                      )}
                    </td>
                    <td style={td}>
                      <span style={{ fontWeight: 700, color: paymentStatus === 'paid' ? '#1f7a1f' : paymentStatus === 'partial' ? '#9c6f00' : '#444' }}>
                        {paymentStatus}
                      </span>
                    </td>
                    <td style={td}>
                      {row.receiptUrl ? (
                        <a href={row.receiptUrl} target="_blank" rel="noreferrer">View Receipt</a>
                      ) : (
                        '-'
                      )}
                    </td>
                    {isAdmin && (
                      <td style={td}>
                        <button style={dangerBtn} onClick={() => handleDelete(row)}>Delete</button>
                      </td>
                    )}
                  </tr>
                );
              })}
              {!filteredRows.length && <tr><td style={{ ...td, textAlign: 'center' }} colSpan={isAdmin ? 12 : 11}>No service PO records yet</td></tr>}
            </tbody>
          </table>
        </div>
      ) : financeVisible ? (
        <>
          <ServicePOApproval rows={filteredRows} vendors={vendors} currentUserRole={currentUserRole} />
          <ServicePOPayment rows={filteredRows} currentUserRole={currentUserRole} />
        </>
      ) : (
        <div style={{ padding: 16, background: '#fff', border: '1px solid #ececec', borderRadius: 8 }}>Approval queue is visible for finance/admin only.</div>
      )}

      <CreateServicePO open={openCreate} onClose={() => setOpenCreate(false)} vendors={vendors} />
    </div>
  );
};

const th = { textAlign: 'left', padding: '12px 10px', borderBottom: '1px solid #ececec', whiteSpace: 'nowrap' };
const td = { padding: '12px 10px', borderBottom: '1px solid #f1f1f1', whiteSpace: 'nowrap' };

const primaryBtn = {
  height: 34,
  border: 'none',
  borderRadius: 6,
  padding: '0 12px',
  background: MAROON,
  color: '#fff',
  fontWeight: 600,
  cursor: 'pointer',
};

const dangerBtn = {
  height: 30,
  border: 'none',
  borderRadius: 6,
  padding: '0 10px',
  background: '#b00',
  color: '#fff',
  cursor: 'pointer',
};

const tabBtn = {
  height: 34,
  border: '1px solid #d9d9d9',
  borderRadius: 6,
  padding: '0 12px',
  background: '#f7f7f7',
  cursor: 'pointer',
};

const inputStyle = {
  height: 36,
  border: '1px solid #d9d9d9',
  borderRadius: 6,
  padding: '0 10px',
};

export default ServicePO;
