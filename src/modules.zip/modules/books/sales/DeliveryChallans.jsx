import React, { useEffect, useState } from 'react';
import { runTransaction, doc, collection, getDocs, collection as fbCollection, addDoc, serverTimestamp, query, where, orderBy } from 'firebase/firestore';
import { auth, db } from '../../../firebaseConfig';

const viewBtn = {
  background: '#8B0000',
  color: '#fff',
  border: 'none',
  borderRadius: 8,
  padding: '8px 14px',
  fontWeight: 600,
  cursor: 'pointer',
};


const DeliveryChallans = () => {
  const [challans, setChallans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterKpi, setFilterKpi] = useState("");
  const [filterDate, setFilterDate] = useState("");
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [currentUser, setCurrentUser] = useState({});
  const isAdmin = String(currentUser?.role || '').toLowerCase() === 'admin';

  useEffect(() => {
    const fetchUser = async () => {
      const user = auth.currentUser;
      let role = '';
      try {
        const session = JSON.parse(localStorage.getItem('kp-user') || '{}');
        role = session?.profile?.role || session?.role || '';
      } catch {}

      if (!role && user?.getIdTokenResult) {
        try {
          const token = await user.getIdTokenResult();
          role = token?.claims?.role || '';
        } catch {}
      }

      setCurrentUser({ role });
    };
    fetchUser();
  }, []);

  useEffect(() => {
    const fetchChallans = async () => {
      setLoading(true);
      try {
        const snap = await getDocs(collection(db, 'deliveryChallans'));
        let rows = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));

        if (filterKpi) {
          const needle = filterKpi.toLowerCase();
          rows = rows.filter((r) => String(r.kpi_id || r.kpiId || '').toLowerCase().includes(needle));
        }

        if (filterDate) {
          const selected = new Date(filterDate);
          const y = selected.getFullYear();
          const m = selected.getMonth();
          const d = selected.getDate();
          rows = rows.filter((r) => {
            const raw = r.createdAt || r.created_at;
            if (!raw) return false;
            const dt = raw?.toDate ? raw.toDate() : new Date(raw);
            if (isNaN(dt.getTime())) return false;
            return dt.getFullYear() === y && dt.getMonth() === m && dt.getDate() === d;
          });
        }

        rows.sort((a, b) => {
          const ad = (a.createdAt || a.created_at)?.toDate ? (a.createdAt || a.created_at).toDate() : new Date(a.createdAt || a.created_at || 0);
          const bd = (b.createdAt || b.created_at)?.toDate ? (b.createdAt || b.created_at).toDate() : new Date(b.createdAt || b.created_at || 0);
          return bd - ad;
        });

        setChallans(rows);
      } catch {
        setChallans([]);
      } finally {
        setLoading(false);
      }
    };
    fetchChallans();
  }, [filterKpi, filterDate]);

  const handleDelete = async (dc) => {
    setDeleting(true);
    try {
      await runTransaction(db, async (transaction) => {
        // 1. Reverse stock movement
        for (const item of dc.items || []) {
          const variantRef = doc(db, 'inventoryVariants', item.variantId);
          const variantSnap = await transaction.get(variantRef);
          if (!variantSnap.exists()) throw new Error('Variant not found');
          const prevQty = Number(variantSnap.data().availableQuantity || 0);
          transaction.update(variantRef, {
            availableQuantity: prevQty + Number(item.quantity || 0),
          });
        }
        // 2. Add stockLedger entry
        await addDoc(fbCollection(db, 'stockLedger'), {
          type: 'stockIN',
          referenceType: 'DC_DELETE',
          referenceId: dc.dcNumber,
          items: dc.items || [],
          createdAt: serverTimestamp(),
        });
        // 3. Delete deliveryChallans document
        transaction.delete(doc(db, 'deliveryChallans', dc.id));
      });
      setChallans((prev) => prev.filter((c) => c.id !== dc.id));
      setConfirmDeleteId(null);
    } catch (err) {
      alert('Failed to delete DC: ' + err.message);
    } finally {
      setDeleting(false);
    }
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div>
      <h2>Delivery Challans</h2>
      <div style={{ marginBottom: 16, display: 'flex', gap: 16 }}>
        <input
          type="text"
          placeholder="Filter by KPI-ID"
          value={filterKpi}
          onChange={e => setFilterKpi(e.target.value)}
          style={{ padding: 6, borderRadius: 4, border: '1px solid #800000' }}
        />
        <input
          type="date"
          value={filterDate}
          onChange={e => setFilterDate(e.target.value)}
          style={{ padding: 6, borderRadius: 4, border: '1px solid #800000' }}
        />
      </div>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th>Created At</th>
            <th>KPI-ID</th>
            <th>Customer Name</th>
            <th>Sales Zone</th>
            <th>DC Number</th>
            <th>View DC</th>
            {isAdmin && <th>Delete</th>}
          </tr>
        </thead>
        <tbody>
          {challans.map(dc => (
            <tr key={dc.id}>
              <td>{dc.createdAt?.toDate ? dc.createdAt.toDate().toLocaleString() : ''}</td>
              <td>{dc.kpi_id}</td>
              <td>{dc.customerName}</td>
              <td>{dc.sales_zone}</td>
              <td>{dc.dcNumber}</td>
              <td>
                {dc.dcPdfUrl ? (
                  <a href={dc.dcPdfUrl} target="_blank" rel="noopener noreferrer"><button style={viewBtn}>View DC</button></a>
                ) : String(dc.status || "").toLowerCase() === 'pdf_failed' ? (
                  <span style={{ color: '#b00', fontWeight: 600 }}>PDF failed</span>
                ) : (
                  <span>Generating PDF...</span>
                )}
              </td>
              {isAdmin && (
                <td>
                  <button
                    style={{ background: '#b00', color: '#fff', border: 'none', borderRadius: 4, padding: '4px 12px' }}
                    onClick={() => setConfirmDeleteId(dc.id)}
                    disabled={deleting}
                  >
                    Delete
                  </button>
                  {confirmDeleteId === dc.id && (
                    <div style={{ position: 'absolute', background: '#fff', border: '1px solid #800000', padding: 12, zIndex: 10 }}>
                      <div>Are you sure you want to delete this DC?</div>
                      <button onClick={() => handleDelete(dc)} disabled={deleting} style={{ marginRight: 8 }}>Yes</button>
                      <button onClick={() => setConfirmDeleteId(null)} disabled={deleting}>No</button>
                    </div>
                  )}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DeliveryChallans;
