import React, { useEffect, useMemo, useState } from 'react';
import { collection, onSnapshot } from 'firebase/firestore';
import { db } from '../../../firebaseConfig';

const MAROON = '#8B0000';

const toDateValue = (row) => {
  if (row?.createdAtMs) return Number(row.createdAtMs);
  const ts = row?.createdAt || row?.updatedAt || null;
  if (ts?.seconds) return Number(ts.seconds) * 1000;
  if (typeof ts === 'string' || ts instanceof Date) {
    const dt = new Date(ts).getTime();
    return Number.isFinite(dt) ? dt : 0;
  }
  if (row?.createdDate) {
    const dt = new Date(row.createdDate).getTime();
    return Number.isFinite(dt) ? dt : 0;
  }
  return 0;
};

const formatDate = (row) => {
  if (row?.createdDate) return String(row.createdDate);
  const t = toDateValue(row);
  if (!t) return '-';
  return new Date(t).toISOString().slice(0, 10);
};

const normalizeItems = (items = []) => {
  if (!Array.isArray(items)) return [];
  return items
    .map((item) => {
      const qty = Number(item?.quantity || 0);
      if (!qty) return null;
      return {
        productName: String(item?.productName || item?.name || item?.productId || item?.variantId || '-'),
        variantName: String(item?.variantName || item?.variantId || '-'),
        specification: String(item?.specification || item?.spec || '-'),
        quantity: qty,
        unit: String(item?.unit || 'Nos'),
      };
    })
    .filter(Boolean);
};

const toProductQtyMap = (items) => {
  const map = {};
  (items || []).forEach((item) => {
    const key = String(item.productName || '-').trim() || '-';
    map[key] = Number(map[key] || 0) + Number(item.quantity || 0);
  });
  return map;
};

const buildCsv = (headers, rows) => {
  const esc = (v) => `"${String(v ?? '').replaceAll('"', '""')}"`;
  const lines = [headers.map(esc).join(',')];
  rows.forEach((r) => {
    lines.push(headers.map((h) => esc(r[h] ?? '')).join(','));
  });
  return lines.join('\n');
};

const downloadCsv = (fileName, headers, rows) => {
  const csv = buildCsv(headers, rows);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  a.click();
  URL.revokeObjectURL(url);
};

const StockInOut = () => {
  const [activeTab, setActiveTab] = useState('stockin');
  const [grnRows, setGrnRows] = useState([]);
  const [creditRows, setCreditRows] = useState([]);
  const [dcRows, setDcRows] = useState([]);
  const [selectedId, setSelectedId] = useState('');

  useEffect(() => {
    const unsubs = [];

    unsubs.push(onSnapshot(collection(db, 'records_grn'), (snap) => {
      const rows = snap.docs.map((d) => {
        const row = d.data() || {};
        const materials = normalizeItems(row.items || []);
        return {
          id: `grn:${d.id}`,
          sourceType: 'GRN',
          createdDate: formatDate(row),
          createdAtMs: toDateValue(row),
          docNumber: row.grnNumber || d.id,
          reference: row.referencePO || row.poId || '-',
          materials,
          productQtyMap: toProductQtyMap(materials),
          totalQty: materials.reduce((sum, x) => sum + Number(x.quantity || 0), 0),
          raw: row,
        };
      });
      setGrnRows(rows);
    }));

    unsubs.push(onSnapshot(collection(db, 'creditNotes'), (snap) => {
      const rows = snap.docs.map((d) => {
        const row = d.data() || {};
        const materials = normalizeItems(row.items || []);
        const kpi = row.kpi_id || row.kpiId || '-';
        return {
          id: `cn:${d.id}`,
          sourceType: 'CN',
          createdDate: formatDate(row),
          createdAtMs: toDateValue(row),
          docNumber: row.creditNoteNumber || `CN/${kpi}`,
          reference: kpi,
          materials,
          productQtyMap: toProductQtyMap(materials),
          totalQty: materials.reduce((sum, x) => sum + Number(x.quantity || 0), 0),
          raw: row,
        };
      });
      setCreditRows(rows);
    }));

    unsubs.push(onSnapshot(collection(db, 'deliveryChallans'), (snap) => {
      const rows = snap.docs.map((d) => {
        const row = d.data() || {};
        const materials = normalizeItems(row.items || []);
        const kpi = row.kpi_id || row.kpiId || '-';
        return {
          id: `dc:${d.id}`,
          sourceType: 'DC',
          createdDate: formatDate(row),
          createdAtMs: toDateValue(row),
          docNumber: row.dcNumber || d.id,
          reference: kpi,
          materials,
          productQtyMap: toProductQtyMap(materials),
          totalQty: materials.reduce((sum, x) => sum + Number(x.quantity || 0), 0),
          raw: row,
        };
      });
      setDcRows(rows);
    }));

    return () => unsubs.forEach((u) => u());
  }, []);

  const stockInRows = useMemo(() => [...grnRows, ...creditRows].sort((a, b) => Number(b.createdAtMs || 0) - Number(a.createdAtMs || 0)), [grnRows, creditRows]);
  const stockOutRows = useMemo(() => [...dcRows].sort((a, b) => Number(b.createdAtMs || 0) - Number(a.createdAtMs || 0)), [dcRows]);

  const currentRows = activeTab === 'stockin' ? stockInRows : stockOutRows;

  const productColumns = useMemo(() => {
    const set = new Set();
    currentRows.forEach((row) => {
      Object.keys(row.productQtyMap || {}).forEach((k) => set.add(k));
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [currentRows]);

  useEffect(() => {
    if (!currentRows.length) {
      setSelectedId('');
      return;
    }
    if (selectedId && !currentRows.some((r) => r.id === selectedId)) {
      setSelectedId('');
    }
  }, [currentRows, selectedId]);

  const selectedRow = useMemo(() => currentRows.find((r) => r.id === selectedId) || null, [currentRows, selectedId]);

  const exportCurrent = () => {
    const baseHeaders = activeTab === 'stockin'
      ? ['Created Date', 'Type', activeTab === 'stockin' ? 'GRN/CN Number' : 'DC Number', 'Reference PO/KPI', 'Total Quantity']
      : ['Created Date', 'DC Number', 'Reference KPI', 'Total Quantity'];

    const headers = [...baseHeaders, ...productColumns];

    const rows = currentRows.map((row) => {
      const obj = {
        'Created Date': row.createdDate,
        ...(activeTab === 'stockin'
          ? {
              Type: row.sourceType,
              'GRN/CN Number': row.docNumber,
              'Reference PO/KPI': row.reference,
              'Total Quantity': row.totalQty,
            }
          : {
              'DC Number': row.docNumber,
              'Reference KPI': row.reference,
              'Total Quantity': row.totalQty,
            }),
      };
      productColumns.forEach((p) => {
        obj[p] = Number(row.productQtyMap?.[p] || 0);
      });
      return obj;
    });

    const name = activeTab === 'stockin' ? 'stock-in-report.csv' : 'stock-out-report.csv';
    downloadCsv(name, headers, rows);
  };

  return (
    <div style={{ display: 'grid', gridTemplateColumns: selectedRow ? 'minmax(0, 1fr) minmax(360px, 42%)' : 'minmax(0, 1fr)', gap: 12 }}>
      <div style={{ background: '#fff', border: '1px solid #e8e8e8', borderRadius: 10, overflow: 'hidden' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: 12, borderBottom: '1px solid #eee' }}>
          <div style={{ display: 'flex', gap: 8 }}>
            <button style={activeTab === 'stockin' ? primaryBtn : secondaryBtn} onClick={() => setActiveTab('stockin')}>Stock In</button>
            <button style={activeTab === 'stockout' ? primaryBtn : secondaryBtn} onClick={() => setActiveTab('stockout')}>Stock Out</button>
          </div>
          <button style={primaryBtn} onClick={exportCurrent}>Export</button>
        </div>

        <div style={{ overflowX: 'auto', maxHeight: '72vh' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: '#f8f8f8' }}>
                <th style={th}>Created Date</th>
                {activeTab === 'stockin' && <th style={th}>Type</th>}
                <th style={th}>{activeTab === 'stockin' ? 'GRN/CN Number' : 'DC Number'}</th>
                <th style={th}>{activeTab === 'stockin' ? 'Reference PO/KPI' : 'Reference KPI'}</th>
                <th style={th}>Total Qty</th>
                {productColumns.map((name) => (
                  <th key={name} style={th}>{name}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {currentRows.map((row) => (
                <tr
                  key={row.id}
                  onClick={() => setSelectedId(row.id)}
                  style={{ cursor: 'pointer', background: row.id === selectedId ? '#f5f9ff' : '#fff' }}
                >
                  <td style={td}>{row.createdDate}</td>
                  {activeTab === 'stockin' && <td style={td}>{row.sourceType}</td>}
                  <td style={td}>{row.docNumber}</td>
                  <td style={td}>{row.reference}</td>
                  <td style={td}>{Number(row.totalQty || 0)}</td>
                  {productColumns.map((name) => (
                    <td key={`${row.id}-${name}`} style={td}>{Number(row.productQtyMap?.[name] || 0)}</td>
                  ))}
                </tr>
              ))}
              {!currentRows.length && (
                <tr>
                  <td style={{ ...td, textAlign: 'center' }} colSpan={activeTab === 'stockin' ? (5 + productColumns.length) : (4 + productColumns.length)}>
                    No {activeTab === 'stockin' ? 'stock-in' : 'stock-out'} records found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {selectedRow ? (
      <div style={{ background: '#fff', border: '1px solid #e8e8e8', borderRadius: 10, padding: 12, minHeight: 240 }}>
        {
          <>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
              <div>
                <div style={{ fontSize: 18, fontWeight: 700, color: '#1f2d3d' }}>{selectedRow.docNumber}</div>
                <div style={{ marginTop: 4, color: '#666' }}>
                  {selectedRow.sourceType === 'GRN' ? 'Reference PO' : selectedRow.sourceType === 'CN' ? 'Reference KPI' : 'Reference KPI'}: {selectedRow.reference}
                </div>
                <div style={{ marginTop: 2, color: '#666' }}>Created Date: {selectedRow.createdDate}</div>
                <div style={{ marginTop: 2, color: '#666' }}>
                  Type: {selectedRow.sourceType}
                </div>
              </div>
              <button style={secondaryBtn} onClick={() => setSelectedId('')}>Close</button>
            </div>

            <div style={{ marginTop: 12, fontWeight: 700 }}>Materials</div>
            <div style={{ marginTop: 8, border: '1px solid #ececec', borderRadius: 8, overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ background: '#fafafa' }}>
                    <th style={thSmall}>Product</th>
                    <th style={thSmall}>Variant</th>
                    <th style={thSmall}>Specification</th>
                    <th style={thSmall}>Quantity</th>
                    <th style={thSmall}>Unit</th>
                  </tr>
                </thead>
                <tbody>
                  {(selectedRow.materials || []).map((item, idx) => (
                    <tr key={`${selectedRow.id}-${idx}`}>
                      <td style={tdSmall}>{item.productName}</td>
                      <td style={tdSmall}>{item.variantName}</td>
                      <td style={tdSmall}>{item.specification}</td>
                      <td style={tdSmall}>{Number(item.quantity || 0)}</td>
                      <td style={tdSmall}>{item.unit}</td>
                    </tr>
                  ))}
                  {!selectedRow.materials?.length && (
                    <tr>
                      <td style={{ ...tdSmall, textAlign: 'center' }} colSpan={5}>No material rows</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </>
        }
      </div>
      ) : null}
    </div>
  );
};

const th = { textAlign: 'left', padding: '10px 12px', borderBottom: '1px solid #ececec', whiteSpace: 'nowrap' };
const td = { textAlign: 'left', padding: '10px 12px', borderBottom: '1px solid #f3f3f3', whiteSpace: 'nowrap' };
const thSmall = { textAlign: 'left', padding: '8px 10px', borderBottom: '1px solid #ececec', whiteSpace: 'nowrap', fontSize: 13 };
const tdSmall = { textAlign: 'left', padding: '8px 10px', borderBottom: '1px solid #f5f5f5', whiteSpace: 'nowrap', fontSize: 13 };

const primaryBtn = {
  height: 34,
  border: 'none',
  borderRadius: 6,
  padding: '0 12px',
  background: MAROON,
  color: '#fff',
  fontWeight: 600,
  cursor: 'pointer',
};

const secondaryBtn = {
  height: 34,
  border: '1px solid #d0d0d0',
  borderRadius: 6,
  padding: '0 12px',
  background: '#fff',
  fontWeight: 600,
  cursor: 'pointer',
};

export default StockInOut;
