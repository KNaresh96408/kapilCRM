import React from 'react';
import { Document, Image, Page, StyleSheet, Text, View } from '@react-pdf/renderer';

const styles = StyleSheet.create({
  page: { padding: 24, fontSize: 10, color: '#111' },
  title: { fontSize: 16, fontWeight: 700, textAlign: 'center', marginBottom: 8 },
  header: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  sectionBox: { border: '1 solid #999', padding: 8, marginBottom: 8 },
  row: { flexDirection: 'row', justifyContent: 'space-between', gap: 10 },
  label: { fontWeight: 700 },
  table: { border: '1 solid #999', marginTop: 8 },
  trHead: { flexDirection: 'row', backgroundColor: '#f3f3f3', borderBottom: '1 solid #999' },
  tr: { flexDirection: 'row', borderBottom: '1 solid #ddd' },
  th: { padding: 6, fontWeight: 700, borderRight: '1 solid #ddd' },
  td: { padding: 6, borderRight: '1 solid #eee' },
  footer: { marginTop: 14, alignItems: 'flex-end' },
});

const widths = {
  sNo: 30,
  productId: 85,
  desc: '36%',
  unit: 45,
  qty: 50,
  poQty: 60,
};

export const GrnPdfDocument = ({ grn = {}, logoUrl = '' }) => {
  const items = Array.isArray(grn.items) ? grn.items : [];

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <Text style={styles.title}>DELIVERY CHALLAN / GOODS RECEIPT NOTE (DC/GRN)</Text>

        <View style={styles.header}>
          <View style={{ width: '62%' }}>
            <Text style={{ fontWeight: 700 }}>Kapil Power & Infra (P) Limited</Text>
            <Text>Financial District, Hyderabad</Text>
            <Text>GSTIN: 36AAFCA3811M1ZO</Text>
          </View>
          <View style={{ width: '38%', alignItems: 'flex-end' }}>
            {logoUrl ? <Image src={logoUrl} style={{ width: 92, height: 44, objectFit: 'contain' }} /> : null}
            <Text style={{ marginTop: 4 }}><Text style={styles.label}>GRN:</Text> {grn.grnNumber || '-'}</Text>
            <Text><Text style={styles.label}>Date:</Text> {grn.createdDate || '-'}</Text>
            <Text><Text style={styles.label}>Ref PO:</Text> {grn.referencePO || '-'}</Text>
          </View>
        </View>

        <View style={styles.sectionBox}>
          <View style={styles.row}>
            <Text><Text style={styles.label}>Vendor Name:</Text> {grn.vendorName || '-'}</Text>
            <Text><Text style={styles.label}>Vendor ID:</Text> {grn.vendorId || '-'}</Text>
          </View>
          <View style={styles.row}>
            <Text><Text style={styles.label}>PO ID:</Text> {grn.poId || '-'}</Text>
            <Text><Text style={styles.label}>Received Items:</Text> {items.length}</Text>
          </View>
        </View>

        <View style={styles.table}>
          <View style={styles.trHead}>
            <Text style={{ ...styles.th, width: widths.sNo }}>#</Text>
            <Text style={{ ...styles.th, width: widths.productId }}>Product ID</Text>
            <Text style={{ ...styles.th, width: widths.desc }}>Description</Text>
            <Text style={{ ...styles.th, width: widths.unit }}>Unit</Text>
            <Text style={{ ...styles.th, width: widths.poQty }}>PO Qty</Text>
            <Text style={{ ...styles.th, width: widths.qty, borderRight: 0 }}>Received</Text>
          </View>

          {items.map((item, idx) => (
            <View style={styles.tr} key={`${item.variantId || idx}-${idx}`}>
              <Text style={{ ...styles.td, width: widths.sNo }}>{idx + 1}</Text>
              <Text style={{ ...styles.td, width: widths.productId }}>{item.productId || '-'}</Text>
              <Text style={{ ...styles.td, width: widths.desc }}>
                {item.productName || '-'} | {item.brandName || '-'} | {item.variantName || '-'}
                {item.specification ? ` (${item.specification})` : ''}
              </Text>
              <Text style={{ ...styles.td, width: widths.unit }}>{item.unit || 'Nos'}</Text>
              <Text style={{ ...styles.td, width: widths.poQty }}>{Number(item.poQuantity || 0)}</Text>
              <Text style={{ ...styles.td, width: widths.qty, borderRight: 0 }}>{Number(item.quantity || 0)}</Text>
            </View>
          ))}
        </View>

        <View style={styles.footer}>
          <Text><Text style={styles.label}>Total Received Qty:</Text> {items.reduce((sum, i) => sum + Number(i.quantity || 0), 0)}</Text>
        </View>
      </Page>
    </Document>
  );
};

export default GrnPdfDocument;
