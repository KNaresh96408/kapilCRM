import React, { useEffect, useMemo, useState } from "react";
import * as XLSX from "xlsx";
import { fetchCollectionDocs } from "../../../helpers/firestoreFetch";
import {
  createDocumentREST,
  updateDocumentREST,
  deleteDocumentREST,
} from "../../../helpers/firestoreRest";

const PAYMENT_TYPES = [
  { key: "first", label: "1st Payment" },
  { key: "second", label: "2nd Payment" },
  { key: "third", label: "3rd Payment" },
  { key: "fourth", label: "4th Payment" },
];

const RECEIVABLES_COLLECTION = "books_payment_receivables";

function getAmountReceived(order) {
  return (order.payments || []).reduce(
    (sum, p) => sum + Number(p.amount || 0),
    0
  );
}

const PaymentReceivables = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeOrderId, setActiveOrderId] = useState(null);
  const [drawerError, setDrawerError] = useState("");
  const [filterKpi, setFilterKpi] = useState("");
  const [filterDate, setFilterDate] = useState("");
  const [exporting, setExporting] = useState(false);
  const [manualDrawerOpen, setManualDrawerOpen] = useState(false);
  const [manualForm, setManualForm] = useState({
    kpi_id: "",
    customer_name: "",
    contact_number: "",
    sales_zone: "",
    sales_area: "",
    invoice_amount: "",
  });
  const [manualError, setManualError] = useState("");
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [paymentForm, setPaymentForm] = useState({
    utr: "",
    amount: "",
    date: "",
  });
  const [editForm, setEditForm] = useState({
    kpi_id: "",
    customer_name: "",
    contact_number: "",
    sales_zone: "",
    sales_area: "",
    invoice_amount: "",
  });

  const refreshOrders = async () => {
    setLoading(true);
    try {
      const rows = await fetchCollectionDocs(RECEIVABLES_COLLECTION);
      const normalized = rows
        .map((r) => ({
          ...r,
          invoice_amount: Number(r.invoice_amount || 0),
          payments: Array.isArray(r.payments) ? r.payments : [],
        }))
        .sort((a, b) => {
          const at = new Date(a.created_at || 0).getTime();
          const bt = new Date(b.created_at || 0).getTime();
          return bt - at;
        });
      setOrders(normalized);
    } catch {
      setDrawerError("Failed to load records.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshOrders();
  }, []);

  const activeOrder = useMemo(
    () => orders.find((o) => o.id === activeOrderId) || null,
    [orders, activeOrderId]
  );

  const handleOpenDrawer = (order) => {
    setActiveOrderId(order.id);
    setEditForm({
      kpi_id: order.kpi_id || "",
      customer_name: order.customer_name || "",
      contact_number: order.contact_number || "",
      sales_zone: order.sales_zone || "",
      sales_area: order.sales_area || "",
      invoice_amount: String(order.invoice_amount || ""),
    });
    setDrawerError("");
    setShowPaymentForm(false);
    setPaymentForm({ utr: "", amount: "", date: "" });
  };

  const handleCloseDrawer = () => {
    setActiveOrderId(null);
    setDrawerError("");
    setShowPaymentForm(false);
    setPaymentForm({ utr: "", amount: "", date: "" });
  };

  const handleCreateRecord = async (e) => {
    e.preventDefault();
    setManualError("");
    if (
      !manualForm.kpi_id ||
      !manualForm.customer_name ||
      !manualForm.contact_number ||
      !manualForm.sales_zone ||
      !manualForm.sales_area ||
      !manualForm.invoice_amount
    ) {
      setManualError("All fields are required.");
      return;
    }
    const invoiceAmount = Number(manualForm.invoice_amount || 0);
    if (invoiceAmount <= 0) {
      setManualError("Invoice Amount must be greater than 0.");
      return;
    }
    const docId = `manual-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const newRecord = {
      kpi_id: manualForm.kpi_id,
      customer_name: manualForm.customer_name,
      contact_number: manualForm.contact_number,
      sales_zone: manualForm.sales_zone,
      sales_area: manualForm.sales_area,
      invoice_amount: invoiceAmount,
      payments: [],
      created_at: new Date().toISOString(),
    };
    try {
      await createDocumentREST(RECEIVABLES_COLLECTION, newRecord, null, docId);
      setManualDrawerOpen(false);
      setManualForm({
        kpi_id: "",
        customer_name: "",
        contact_number: "",
        sales_zone: "",
        sales_area: "",
        invoice_amount: "",
      });
      await refreshOrders();
    } catch {
      setManualError("Failed to save record. Please try again.");
    }
  };

  const handleSaveRecord = async () => {
    if (!activeOrder) return;
    setDrawerError("");
    if (
      !editForm.kpi_id ||
      !editForm.customer_name ||
      !editForm.contact_number ||
      !editForm.sales_zone ||
      !editForm.sales_area ||
      !editForm.invoice_amount
    ) {
      setDrawerError("All record fields are required.");
      return;
    }
    const invoiceAmount = Number(editForm.invoice_amount || 0);
    const received = getAmountReceived(activeOrder);
    if (invoiceAmount < received) {
      setDrawerError("Invoice Amount cannot be less than Amount Received.");
      return;
    }

    try {
      await updateDocumentREST(RECEIVABLES_COLLECTION, activeOrder.id, {
        kpi_id: editForm.kpi_id,
        customer_name: editForm.customer_name,
        contact_number: editForm.contact_number,
        sales_zone: editForm.sales_zone,
        sales_area: editForm.sales_area,
        invoice_amount: invoiceAmount,
        updated_at: new Date().toISOString(),
      });
      await refreshOrders();
      handleCloseDrawer();
    } catch {
      setDrawerError("Failed to save record.");
    }
  };

  const handleDeleteRecord = async () => {
    if (!activeOrder) return;
    try {
      await deleteDocumentREST(RECEIVABLES_COLLECTION, activeOrder.id);
      await refreshOrders();
      handleCloseDrawer();
    } catch {
      setDrawerError("Failed to delete record.");
    }
  };

  const handleAddPayment = async (e) => {
    e.preventDefault();
    if (!activeOrder) return;
    setDrawerError("");

    const nextType = PAYMENT_TYPES[(activeOrder.payments || []).length];
    if (!nextType) {
      setDrawerError("Maximum 4 payments reached.");
      return;
    }

    const amount = Number(paymentForm.amount || 0);
    const pendingAmount = Number(activeOrder.invoice_amount || 0) - getAmountReceived(activeOrder);

    if (!paymentForm.utr || !paymentForm.date || amount <= 0) {
      setDrawerError("Payment UTR, amount, and date are required.");
      return;
    }
    if (amount > pendingAmount) {
      setDrawerError("Payment exceeds pending amount.");
      return;
    }

    const newPayment = {
      id: `pay-${Date.now()}`,
      type: nextType.key,
      label: nextType.label,
      utr: paymentForm.utr,
      amount,
      date: paymentForm.date,
      created_at: new Date().toISOString(),
    };

    try {
      await updateDocumentREST(RECEIVABLES_COLLECTION, activeOrder.id, {
        payments: [...(activeOrder.payments || []), newPayment],
        updated_at: new Date().toISOString(),
      });
      await refreshOrders();
      setPaymentForm({ utr: "", amount: "", date: "" });
      setShowPaymentForm(false);
    } catch {
      setDrawerError("Failed to save payment.");
    }
  };

  let filteredOrders = orders;
  if (filterKpi) {
    filteredOrders = filteredOrders.filter((o) =>
      (o.kpi_id || "").toLowerCase().includes(filterKpi.toLowerCase())
    );
  }
  if (filterDate) {
    filteredOrders = filteredOrders.filter((o) =>
      (o.payments || []).some((p) => p.date === filterDate)
    );
  }

  // Export to Excel
  const handleExport = () => {
    setExporting(true);
    const data = filteredOrders.map((order) => {
      const amountReceived = getAmountReceived(order);
      const pendingAmount = Number(order.invoice_amount || 0) - amountReceived;
      return {
        "KPI-ID": order.kpi_id,
        "Customer Name": order.customer_name,
        "Contact Number": order.contact_number,
        "Sales Zone": order.sales_zone,
        "Sales Area": order.sales_area,
        "Invoice Amount": order.invoice_amount,
        "Amount Received": amountReceived,
        "Pending Amount": pendingAmount,
      };
    });
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Receivables");
    XLSX.writeFile(wb, "PaymentReceivables.xlsx");
    setExporting(false);
  };

  return (
    <div style={{ paddingLeft: 16 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
        <h2 style={{ color: "#800000", marginBottom: 0 }}>Payment Receivables</h2>
        <button
          style={{ background: "#800000", color: "#fff", border: "none", borderRadius: 4, padding: "8px 20px", fontWeight: 600, fontSize: 15, cursor: "pointer" }}
          onClick={() => setManualDrawerOpen(true)}
        >
          + Add Manual Payment
        </button>
      </div>
      <div style={{ marginBottom: 8, display: "flex", gap: 8 }}>
        <input
          type="text"
          placeholder="Filter by KPI-ID"
          value={filterKpi}
          onChange={(e) => setFilterKpi(e.target.value)}
          style={{ padding: 6, borderRadius: 4, border: "1px solid #800000" }}
        />
        <input
          type="date"
          value={filterDate}
          onChange={(e) => setFilterDate(e.target.value)}
          style={{ padding: 6, borderRadius: 4, border: "1px solid #800000" }}
        />
        <button
          onClick={handleExport}
          disabled={exporting}
          style={{
            background: "#800000",
            color: "#fff",
            border: "none",
            borderRadius: 4,
            padding: "6px 16px",
          }}
        >
          Export
        </button>
      </div>

      {manualDrawerOpen && (
        <div
          style={{
            position: "fixed",
            top: 0,
            right: 0,
            width: 380,
            height: "100vh",
            background: "#fff",
            boxShadow: "-2px 0 16px rgba(0,0,0,0.15)",
            zIndex: 2000,
            padding: 24,
            display: "flex",
            flexDirection: "column",
          }}
        >
          <h3 style={{ color: "#800000", marginTop: 0 }}>Add Manual Record</h3>
          <form onSubmit={handleCreateRecord} style={{ overflowY: "auto", paddingRight: 4 }}>
            <label style={{ fontWeight: 500 }}>KPI-ID<br /><input value={manualForm.kpi_id} onChange={(e) => setManualForm((f) => ({ ...f, kpi_id: e.target.value }))} style={{ width: "100%", marginBottom: 8 }} required /></label>
            <label style={{ fontWeight: 500 }}>Customer Name<br /><input value={manualForm.customer_name} onChange={(e) => setManualForm((f) => ({ ...f, customer_name: e.target.value }))} style={{ width: "100%", marginBottom: 8 }} required /></label>
            <label style={{ fontWeight: 500 }}>Contact Number<br /><input value={manualForm.contact_number} onChange={(e) => setManualForm((f) => ({ ...f, contact_number: e.target.value }))} style={{ width: "100%", marginBottom: 8 }} required /></label>
            <label style={{ fontWeight: 500 }}>Sales Zone<br /><input value={manualForm.sales_zone} onChange={(e) => setManualForm((f) => ({ ...f, sales_zone: e.target.value }))} style={{ width: "100%", marginBottom: 8 }} required /></label>
            <label style={{ fontWeight: 500 }}>Sales Area<br /><input value={manualForm.sales_area} onChange={(e) => setManualForm((f) => ({ ...f, sales_area: e.target.value }))} style={{ width: "100%", marginBottom: 8 }} required /></label>
            <label style={{ fontWeight: 500 }}>Invoice Amount<br /><input type="number" value={manualForm.invoice_amount} onChange={(e) => setManualForm((f) => ({ ...f, invoice_amount: e.target.value }))} style={{ width: "100%", marginBottom: 8 }} required /></label>
            {manualError && <div style={{ color: "red", marginBottom: 8 }}>{manualError}</div>}
            <div style={{ display: "flex", gap: 12, marginTop: 12 }}>
              <button type="button" onClick={() => setManualDrawerOpen(false)} style={{ background: "#eee", padding: "8px 20px", borderRadius: 4, border: "none" }}>Cancel</button>
              <button type="submit" style={{ background: "#800000", color: "#fff", padding: "8px 20px", borderRadius: 4, border: "none", fontWeight: 600 }}>Save</button>
            </div>
          </form>
        </div>
      )}

      <div style={{ height: 8 }} />
      {loading ? (
        <div>Loading...</div>
      ) : (
        <table
          style={{
            width: "100%",
            borderCollapse: "collapse",
            background: "#fff",
            color: "#222",
          }}
        >
          <thead>
            <tr style={{ background: "#800000", color: "#fff" }}>
              <th>KPI-ID</th>
              <th>Customer Name</th>
              <th>Contact Number</th>
              <th>Sales Zone</th>
              <th>Sales Area</th>
              <th>Invoice Amount</th>
              <th>Amount Received</th>
              <th>Pending Amount</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {filteredOrders.map((order) => {
              const amountReceived = getAmountReceived(order);
              const pendingAmount = Number(order.invoice_amount || 0) - amountReceived;
              return (
                <tr key={order.id}>
                  <td>{order.kpi_id}</td>
                  <td>{order.customer_name}</td>
                  <td>{order.contact_number}</td>
                  <td>{order.sales_zone}</td>
                  <td>{order.sales_area}</td>
                  <td>{order.invoice_amount}</td>
                  <td>{amountReceived}</td>
                  <td>{pendingAmount}</td>
                  <td>
                    <button
                      style={{
                        background: '#800000',
                        color: '#fff',
                        border: 'none',
                        borderRadius: 4,
                        padding: '4px 12px',
                        cursor: 'pointer',
                      }}
                      onClick={() => handleOpenDrawer(order)}
                    >
                      View / Add Payment
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}

      {activeOrder && (
        <div
          style={{
            position: "fixed",
            top: 0,
            right: 0,
            width: 460,
            height: "100vh",
            background: "#fff",
            boxShadow: "-2px 0 16px rgba(0,0,0,0.15)",
            zIndex: 2200,
            display: "flex",
            flexDirection: "column",
          }}
        >
          <div style={{ padding: 20, borderBottom: "1px solid #eee" }}>
            <h3 style={{ color: "#800000", margin: 0 }}>Payment Drawer</h3>
          </div>

          <div style={{ flex: 1, overflowY: "auto", padding: 20 }}>
            <label style={{ fontWeight: 500 }}>KPI-ID<br /><input value={editForm.kpi_id} onChange={(e) => setEditForm((f) => ({ ...f, kpi_id: e.target.value }))} style={{ width: "100%", marginBottom: 8 }} /></label>
            <label style={{ fontWeight: 500 }}>Customer Name<br /><input value={editForm.customer_name} onChange={(e) => setEditForm((f) => ({ ...f, customer_name: e.target.value }))} style={{ width: "100%", marginBottom: 8 }} /></label>
            <label style={{ fontWeight: 500 }}>Contact Number<br /><input value={editForm.contact_number} onChange={(e) => setEditForm((f) => ({ ...f, contact_number: e.target.value }))} style={{ width: "100%", marginBottom: 8 }} /></label>
            <label style={{ fontWeight: 500 }}>Sales Zone<br /><input value={editForm.sales_zone} onChange={(e) => setEditForm((f) => ({ ...f, sales_zone: e.target.value }))} style={{ width: "100%", marginBottom: 8 }} /></label>
            <label style={{ fontWeight: 500 }}>Sales Area<br /><input value={editForm.sales_area} onChange={(e) => setEditForm((f) => ({ ...f, sales_area: e.target.value }))} style={{ width: "100%", marginBottom: 8 }} /></label>
            <label style={{ fontWeight: 500 }}>Invoice Amount<br /><input type="number" value={editForm.invoice_amount} onChange={(e) => setEditForm((f) => ({ ...f, invoice_amount: e.target.value }))} style={{ width: "100%", marginBottom: 8 }} /></label>

            <div style={{ marginBottom: 10 }}><b>Amount Received:</b> {getAmountReceived(activeOrder)}</div>
            <div style={{ marginBottom: 16 }}><b>Pending Amount:</b> {Number(activeOrder.invoice_amount || 0) - getAmountReceived(activeOrder)}</div>

            <button
              style={{ background: "#800000", color: "#fff", border: "none", borderRadius: 4, padding: "8px 20px", fontWeight: 600, cursor: "pointer", marginBottom: 14 }}
              onClick={() => {
                setShowPaymentForm((prev) => !prev);
                setDrawerError("");
              }}
            >
              Add Payment
            </button>

            {showPaymentForm && (
              <form onSubmit={handleAddPayment} style={{ border: "1px solid #eee", borderRadius: 6, padding: 12, marginBottom: 16 }}>
                <div style={{ marginBottom: 8 }}>
                  <b>Payment Type:</b> {PAYMENT_TYPES[(activeOrder.payments || []).length]?.label || "All used"}
                </div>
                <label style={{ display: "block", marginBottom: 8 }}>UTR<br /><input value={paymentForm.utr} onChange={(e) => setPaymentForm((f) => ({ ...f, utr: e.target.value }))} style={{ width: "100%" }} required /></label>
                <label style={{ display: "block", marginBottom: 8 }}>Amount<br /><input type="number" value={paymentForm.amount} onChange={(e) => setPaymentForm((f) => ({ ...f, amount: e.target.value }))} style={{ width: "100%" }} required /></label>
                <label style={{ display: "block", marginBottom: 8 }}>Date<br /><input type="date" value={paymentForm.date} onChange={(e) => setPaymentForm((f) => ({ ...f, date: e.target.value }))} style={{ width: "100%" }} required /></label>
                <div style={{ display: "flex", gap: 8 }}>
                  <button type="button" onClick={() => setShowPaymentForm(false)} style={{ background: "#eee", border: "none", borderRadius: 4, padding: "6px 12px" }}>Cancel</button>
                  <button type="submit" style={{ background: "#800000", color: "#fff", border: "none", borderRadius: 4, padding: "6px 12px" }}>Save Payment</button>
                </div>
              </form>
            )}

            <div>
              <b>Payment History</b>
              {(activeOrder.payments || []).length === 0 && (
                <div style={{ color: "#777", marginTop: 8 }}>No payments yet.</div>
              )}
              {(activeOrder.payments || []).map((p) => (
                <div key={p.id} style={{ border: "1px solid #eee", borderRadius: 6, padding: 10, marginTop: 8 }}>
                  <div><b>{p.label}</b></div>
                  <div>Amount: {Number(p.amount || 0)}</div>
                  <div>Date: {p.date || "-"}</div>
                  <div>UTR: {p.utr || "-"}</div>
                </div>
              ))}
            </div>

            {drawerError && <div style={{ color: "red", marginTop: 12 }}>{drawerError}</div>}
          </div>

          <div style={{ padding: 16, borderTop: "1px solid #eee", display: "flex", gap: 10, justifyContent: "flex-end", background: "#fff" }}>
            <button onClick={handleDeleteRecord} style={{ background: "#d00000", color: "#fff", border: "none", borderRadius: 4, padding: "8px 16px", fontWeight: 600 }}>Delete</button>
            <button onClick={handleCloseDrawer} style={{ background: "#eee", border: "none", borderRadius: 4, padding: "8px 16px" }}>Cancel</button>
            <button onClick={handleSaveRecord} style={{ background: "#800000", color: "#fff", border: "none", borderRadius: 4, padding: "8px 16px", fontWeight: 600 }}>Save</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PaymentReceivables;