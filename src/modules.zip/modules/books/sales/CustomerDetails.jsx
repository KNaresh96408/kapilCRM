import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { db } from '../../../firebaseConfig';
import { collection, getDocs } from 'firebase/firestore';
import CustomerDetailsDCModal from './CustomerDetailsDCModal';
import { createAndUploadInvoice } from './createAndUploadInvoice';
import CustomerDetailsCreditNoteModal from './CustomerDetailsCreditNoteModal';


const CustomerDetails = () => {
  const navigate = useNavigate();

  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dcModalOpen, setDCModalOpen] = useState(false);
  const [creditNoteModalOpen, setCreditNoteModalOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [dcCreated, setDCCreated] = useState({});
  const [dcKpiSet, setDcKpiSet] = useState(new Set());
  const [invoiceKpiSet, setInvoiceKpiSet] = useState(new Set());
  const [creditNoteKpiSet, setCreditNoteKpiSet] = useState(new Set());
  const [filterKpi, setFilterKpi] = useState("");
  const [filterDate, setFilterDate] = useState("");
  const [creatingInvoiceId, setCreatingInvoiceId] = useState(null);

  useEffect(() => {
    const fetchAll = async () => {
      setLoading(true);
      try {
        const ordersSnap = await getDocs(collection(db, 'salesOrders'));
        const [dcRes, invRes, cnRes] = await Promise.allSettled([
          getDocs(collection(db, 'deliveryChallans')),
          getDocs(collection(db, 'invoices')),
          getDocs(collection(db, 'creditNotes')),
        ]);

        let rows = ordersSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));

        if (filterKpi) {
          const needle = filterKpi.toLowerCase();
          rows = rows.filter((o) => {
            const kpi = String(o.kpi_id || o.kpiId || '').toLowerCase();
            return kpi.includes(needle);
          });
        }

        if (filterDate) {
          const selected = new Date(filterDate);
          const y = selected.getFullYear();
          const m = selected.getMonth();
          const d = selected.getDate();

          rows = rows.filter((o) => {
            const raw = o.createdAt || o.created_at || o.updatedAt || o.updated_at || null;
            if (!raw) return false;
            const dt = raw?.toDate ? raw.toDate() : new Date(raw);
            if (isNaN(dt.getTime())) return false;
            return dt.getFullYear() === y && dt.getMonth() === m && dt.getDate() === d;
          });
        }

        const dcDocs = dcRes.status === 'fulfilled' ? dcRes.value.docs : [];
        const invDocs = invRes.status === 'fulfilled' ? invRes.value.docs : [];
        const cnDocs = cnRes.status === 'fulfilled' ? cnRes.value.docs : [];

        setOrders(rows);
        setDcKpiSet(new Set(
          dcDocs
            .map((doc) => String(doc.data().kpi_id || doc.data().kpiId || '').trim().toLowerCase())
            .filter(Boolean)
        ));
        setInvoiceKpiSet(new Set(
          invDocs
            .map((doc) => String(doc.data().kpi_id || doc.data().kpiId || '').trim().toLowerCase())
            .filter(Boolean)
        ));
        setCreditNoteKpiSet(new Set(
          cnDocs
            .map((doc) => String(doc.data().kpi_id || doc.data().kpiId || '').trim().toLowerCase())
            .filter(Boolean)
        ));
      } catch (err) {
        setOrders([]);
        setDcKpiSet(new Set());
        setInvoiceKpiSet(new Set());
        setCreditNoteKpiSet(new Set());
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, [filterKpi, filterDate]);

  const handleOpenDCModal = (order) => {
    setSelectedOrder(order);
    setDCModalOpen(true);
  };
  const handleCloseDCModal = () => {
    setDCModalOpen(false);
    setSelectedOrder(null);
  };
  const handleDCSuccess = () => {
    setDCCreated((prev) => ({ ...prev, [selectedOrder.id]: true }));
  };

  const handleOpenCreditNoteModal = (order) => {
    setSelectedOrder(order);
    setCreditNoteModalOpen(true);
  };

  const handleCloseCreditNoteModal = () => {
    setCreditNoteModalOpen(false);
    setSelectedOrder(null);
  };

  const handleCreditNoteSuccess = () => {
    const normalizedKpi = String(selectedOrder?.kpi_id || selectedOrder?.kpiId || '').trim().toLowerCase();
    setCreditNoteKpiSet((prev) => {
      const next = new Set(prev);
      if (normalizedKpi) next.add(normalizedKpi);
      return next;
    });
  };

  const handleCreateInvoice = async (order) => {
    try {
      setCreatingInvoiceId(order.id);
      await createAndUploadInvoice(order);
      const normalizedKpi = String(order.kpi_id || order.kpiId || '').trim().toLowerCase();
      setInvoiceKpiSet((prev) => {
        const next = new Set(prev);
        if (normalizedKpi) next.add(normalizedKpi);
        return next;
      });
      navigate('/books/sales/invoices');
    } catch (err) {
      alert(err?.message || 'Failed to create invoice');
    } finally {
      setCreatingInvoiceId(null);
    }
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div style={{ paddingLeft: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8, marginTop: 8 }}>
        <h2 style={{ color: '#800000', fontWeight: 700, marginBottom: 0 }}>Customer Details</h2>
        <button style={{ background: '#800000', color: '#fff', border: 'none', borderRadius: 4, padding: '8px 24px', fontWeight: 600, fontSize: 16, cursor: 'pointer' }}>Export</button>
      </div>
      <div style={{ marginBottom: 8, display: 'flex', gap: 8 }}>
        <input
          type="text"
          placeholder="Filter by KPI-ID"
          value={filterKpi}
          onChange={e => setFilterKpi(e.target.value)}
          style={{ padding: 6, borderRadius: 4, border: '1px solid #800000' }}
        />
        <input
          type="date"
          value={filterDate}
          onChange={e => setFilterDate(e.target.value)}
          style={{ padding: 6, borderRadius: 4, border: '1px solid #800000' }}
        />
      </div>
      <div style={{ height: 8 }} />
      <table style={{ width: '100%', borderCollapse: 'collapse', background: '#fff' }}>
        <thead>
          <tr style={{ background: '#800000' }}>
            <th style={{ color: '#fff', fontWeight: 700, padding: '12px 8px' }}>KPI-ID</th>
            <th style={{ color: '#fff', fontWeight: 700, padding: '12px 8px' }}>Customer Name</th>
            <th style={{ color: '#fff', fontWeight: 700, padding: '12px 8px' }}>Contact Number</th>
            <th style={{ color: '#fff', fontWeight: 700, padding: '12px 8px' }}>Address</th>
            <th style={{ color: '#fff', fontWeight: 700, padding: '12px 8px' }}>Sales Zone</th>
            <th style={{ color: '#fff', fontWeight: 700, padding: '12px 8px' }}>Sales Area</th>
            <th style={{ color: '#fff', fontWeight: 700, padding: '12px 8px' }}>Invoice Amount</th>
            <th style={{ color: '#fff', fontWeight: 700, padding: '12px 8px' }}>Payment Received</th>
            <th style={{ color: '#fff', fontWeight: 700, padding: '12px 8px' }}>Pending Amount</th>
            <th style={{ color: '#fff', fontWeight: 700, padding: '12px 8px' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {orders.map(order => {
            const payments = [
              order.firstPayment,
              order.first_payment,
              order.secondPayment,
              order.second_payment,
              order.thirdPayment,
              order.third_payment,
              order.fourthPayment,
              order.fourth_payment,
            ];
            const paymentReceived = payments.reduce((sum, p) => {
              const value = Number(p || 0);
              return sum + (isNaN(value) ? 0 : value);
            }, 0);
            const invoiceAmount = Number(order.invoice_amount ?? order.invoiceAmount ?? 0);
            const pendingAmount = invoiceAmount - paymentReceived;
            const rowKpiId = order.kpi_id || order.kpiId || '';
            const rowCustomerName =
              order.customer_name ||
              order.customerName ||
              order.customer ||
              order.clientName ||
              order.accountName ||
              order.name ||
              '';
            const rowContact =
              order.contact_number ||
              order.contactNumber ||
              order.customerPhone ||
              order.phone ||
              order.mobile ||
              '';
            const rowAddress = order.address || order.location || '';
            const rowZone = order.sales_zone || order.salesZone || '';
            const rowArea = order.sales_area || order.salesArea || '';
            // Button logic using normalized KPI + local DC creation state
            const normalizedKpi = String(rowKpiId || '').trim().toLowerCase();
            const hasDC = dcKpiSet.has(normalizedKpi) || !!dcCreated[order.id];
            const hasInvoice = invoiceKpiSet.has(normalizedKpi);
            const hasCreditNote = creditNoteKpiSet.has(normalizedKpi);
            const dcDisabled = false;
            const invoiceDisabled = !hasDC || hasInvoice;
            const creditNoteDisabled = !hasInvoice;
            return (
              <tr key={order.id}>
                <td>{rowKpiId}</td>
                <td>{rowCustomerName}</td>
                <td>{rowContact}</td>
                <td>{rowAddress}</td>
                <td>{rowZone}</td>
                <td>{rowArea}</td>
                <td>{invoiceAmount}</td>
                <td>{paymentReceived}</td>
                <td>{pendingAmount}</td>
                <td style={{ minWidth: 220 }}>
                  <button
                    onClick={() => handleOpenDCModal(order)}
                    disabled={dcDisabled}
                    style={{
                      background: dcDisabled ? '#ccc' : '#800000',
                      color: '#fff',
                      border: 'none',
                      borderRadius: 4,
                      padding: '8px 16px',
                      fontWeight: 600,
                      marginRight: 8,
                      cursor: dcDisabled ? 'not-allowed' : 'pointer',
                    }}
                  >
                    Create DC
                  </button>
                  <button
                    onClick={() => handleCreateInvoice(order)}
                    disabled={invoiceDisabled}
                    style={{
                      background: invoiceDisabled ? '#ccc' : '#800000',
                      color: '#fff',
                      border: 'none',
                      borderRadius: 4,
                      padding: '8px 16px',
                      fontWeight: 600,
                      marginRight: 8,
                      cursor: invoiceDisabled ? 'not-allowed' : 'pointer',
                    }}
                  >
                    {creatingInvoiceId === order.id ? 'Creating...' : 'Create Invoice'}
                  </button>
                  <button
                    onClick={() => handleOpenCreditNoteModal(order)}
                    disabled={creditNoteDisabled}
                    style={{
                      background: creditNoteDisabled ? '#ccc' : '#800000',
                      color: '#fff',
                      border: 'none',
                      borderRadius: 4,
                      padding: '8px 16px',
                      fontWeight: 600,
                      cursor: creditNoteDisabled ? 'not-allowed' : 'pointer',
                    }}
                  >
                    Credit Notes
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <CustomerDetailsDCModal
        open={dcModalOpen}
        onClose={handleCloseDCModal}
        salesOrder={selectedOrder}
        onSuccess={handleDCSuccess}
      />
      <CustomerDetailsCreditNoteModal
        open={creditNoteModalOpen}
        onClose={handleCloseCreditNoteModal}
        salesOrder={selectedOrder}
        onSuccess={handleCreditNoteSuccess}
      />
    </div>
  );
};

export default CustomerDetails;
